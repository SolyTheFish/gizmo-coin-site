// netlify/functions/gizmo-holders.js
export default async (req, context) => {
  const API_KEY = process.env.BIRDEYE_API_KEY;       // set in Netlify env vars
  const MINT = process.env.GIZMO_MINT_ADDRESS;       // set in Netlify env vars
  const CHAIN = 'solana';

  if (!API_KEY || !MINT) {
    return new Response(JSON.stringify({ error: 'Missing config: BIRDEYE_API_KEY or GIZMO_MINT_ADDRESS' }), {
      status: 500,
      headers: { 'content-type': 'application/json' }
    });
  }

  try {
    const url = `https://public-api.birdeye.so/defi/v3/token/holder?address=${MINT}&chain=${CHAIN}&limit=1&offset=0`;

    const res = await fetch(url, {
      headers: {
        'accept': 'application/json',
        'X-API-KEY': API_KEY
      }
    });

    if (!res.ok) {
      return new Response(JSON.stringify({ error: 'Upstream error', status: res.status }), {
        status: 502,
        headers: { 'content-type': 'application/json' }
      });
    }

    const data = await res.json();

    const holders =
      data?.data?.holder_count ??
      data?.data?.total_holder ??
      data?.holder_count ??
      data?.total_holder ??
      data?.total ??
      data?.count ??
      null;

    return new Response(JSON.stringify({ holders }), {
      headers: { 'content-type': 'application/json' }
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), {
      status: 500,
      headers: { 'content-type': 'application/json' }
    });
  }
};
